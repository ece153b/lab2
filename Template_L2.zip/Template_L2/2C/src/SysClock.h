/*
 * ECE 153B
 *
 * Name(s):
 * Section:
 * Lab: 2C
 */


#ifndef __STM32L476G_NUCLEO_CLOCK_H
#define __STM32L476G_NUCLEO_CLOCK_H

#include "stm32l476xx.h"

void System_Clock_Init(void);

#endif
